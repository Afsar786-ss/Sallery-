Afsar Mobile Paise ka Hisab Android project

Features: record amount/date/optional note, monthly total, copy/share report, CSV export, JSON backup/restore.
Build with Android Gradle Plugin 8.7.3 and Gradle 8.9+ on JDK 17.
